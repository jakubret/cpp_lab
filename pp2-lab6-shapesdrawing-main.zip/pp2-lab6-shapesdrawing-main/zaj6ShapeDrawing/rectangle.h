#include "shape.h"
#ifndef ZAD4SHAPEDRAWING_DLASTUDENTOW_RECTANGLE_H
#define ZAD4SHAPEDRAWING_DLASTUDENTOW_RECTANGLE_H

#endif //ZAD4SHAPEDRAWING_DLASTUDENTOW_RECTANGLE_H

namespace Shapes{
    //class Rectangle{

   // };

}
/*
class Rectangle : public Shapes::Shape {
public:
    //int xFrom_, yFrom_, xTo_, yTo_;
    Rectangle(int xFrom, int yFrom, int xTo, int yTo)
            :xFrom_{xFrom},yFrom_{yFrom},xTo_(xTo),yTo_(yTo){}
    bool isIn(int x, int y) const override{
        return xFrom_<=x && yFrom_<=y && xTo_>=x && yTo_ >=y;
    }

private:
    int xFrom_, yFrom_, xTo_, yTo_;
}; */