#include "circle.h"
/*
Circle::Circle(int xCenter, int yCenter, int radius) {

}

 */