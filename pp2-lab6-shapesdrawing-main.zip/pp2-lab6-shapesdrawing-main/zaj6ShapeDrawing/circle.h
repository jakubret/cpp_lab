#include "shape.h"
#ifndef ZAD4SHAPEDRAWING_DLASTUDENTOW_CIRCLE_H
#define ZAD4SHAPEDRAWING_DLASTUDENTOW_CIRCLE_H

#endif //ZAD4SHAPEDRAWING_DLASTUDENTOW_CIRCLE_H
/*
class Circle : public Shapes::Shape{
public:
    Circle(int xCenter, int yCenter, int radius);

};


 */