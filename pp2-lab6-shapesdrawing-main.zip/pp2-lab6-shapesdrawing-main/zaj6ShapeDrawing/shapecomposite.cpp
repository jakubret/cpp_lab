//
// Created by Acer Nitro 5 on 05.04.2023.
//
#include "shapecomposite.h"