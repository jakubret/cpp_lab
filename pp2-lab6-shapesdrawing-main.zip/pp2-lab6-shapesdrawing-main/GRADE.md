Dear Student,

I'm happy to announce that you've managed to get **3.0** out of 3 points for this assignment.
There is nothing more to say, just please receive my [congratulations](https://youtu.be/1Bix44C1EzY).

-----------
I remain your faithful servant\
_Bobot_