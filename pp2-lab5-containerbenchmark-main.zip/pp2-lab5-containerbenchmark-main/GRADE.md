Dear Student,

I'm happy to announce that you've managed to get **3.0** out of 3 points for this assignment.

There still exist some issues that should be addressed before the deadline: **2023-04-22 23:50:00 CEST (+0200)**. For further details, please refer to the following list:

<details><summary>Ostrzeżenia w trakcie kompilacji</summary>/tmp/tmp87bnk30z/student/lab5ContainerBenchmark/containerWrapper.cpp:12:6: warning: #warning is a GCC extension<br>&nbsp;&nbsp;&nbsp;12 |     #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|      ^~~~~~~<br>/tmp/tmp87bnk30z/student/lab5ContainerBenchmark/containerWrapper.cpp:12:6: warning: #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym" [-Wcpp]<br></details>
<details><summary>Cppcheck znalazł potencjalne błędy (to narzędzie może się pomylić)</summary>/tmp/tmp87bnk30z/student/lab5ContainerBenchmark/containerWrapper.h:221:18: warning: Consider using std::accumulate algorithm instead of a raw loop. [useStlAlgorithm]<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sum1 += val;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;^<br>/tmp/tmp87bnk30z/student/lab5ContainerBenchmark/containerWrapper.h:231:39: warning: Consider using std::find_if algorithm instead of a raw loop. [useStlAlgorithm]<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if (impl_[pos] == needle) {<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;^<br></details>

-----------
I remain your faithful servant\
_Bobot_