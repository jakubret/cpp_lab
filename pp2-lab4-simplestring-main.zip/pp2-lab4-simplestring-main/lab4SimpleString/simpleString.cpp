#include <iostream>
#include <algorithm>
#include <cstring>
#include <utility> // std::exchange
#include <cassert>
using namespace std;

#include "simpleString.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym"
#else
    #pragma message ("Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym")
#endif
const char* SimpleString::c_str() const {
    if (size_ == 0) {
        return "";
    } else {
        assert(data_[size_] == '\0');
        return data_;

    }
}
size_t SimpleString::instances_=0;
SimpleString::SimpleString():size_(0),capacity_(0),data_(new char[0]){
    ++instances_;
}


SimpleString::SimpleString(const char* text) : size_(std::strlen(text)), capacity_(std::strlen(text))
    {
    ++instances_;
    delete[] data_;
    data_= new char[size_+50];
    std::strcpy(data_,text);
}


SimpleString::SimpleString(const SimpleString& text) : SimpleString(text.data_) {

}


SimpleString &SimpleString::assign(const char* new_text){

    //data_= new char[size_+1];
    if (new_text) {

        char* new_data = new char[std::strlen(new_text) + 1];
        std::strcpy(new_data, new_text);
        delete[] data_;
        data_ = new_data;
        size_ = std::strlen(new_text);
        capacity_ = size_;

        //delete[] new_data;
    } else {
        delete[] data_;
        data_ = new char[0];
        size_ = 0;
        capacity_ = 0;
    }

    return *this;
}

SimpleString::~SimpleString() {
    --instances_;
    delete[] data_;
    data_ = {};
    size_ = capacity_ = {};

}
bool SimpleString::equal_to(const SimpleString& SimpleString2,bool case_sensitive) const{
    if(this == &SimpleString2){
        return true;
    }
    if(size_ != SimpleString2.size_){
        return false;
    }
    if (case_sensitive) {
        return std::strcmp(data_, SimpleString2.data_) == 0;
    }
    else {
        for (std::size_t i = 0; i < size_; ++i) {
            if (std::tolower(data_[i]) != std::tolower(SimpleString2.data_[i])) {
                return false;
            }
        }
        return true;
    }
}


SimpleString &SimpleString::append(const SimpleString& SimpleString2 ){
    char* new_data = new char[size_ + SimpleString2.size_ + 1];
    std::memcpy(new_data, data_, size_);
    std::memcpy(new_data + size_, SimpleString2.data_, SimpleString2.size_);

    new_data[size_ + SimpleString2.size_] = '\0';

    delete[] data_;
    data_ = new_data;
    size_ += SimpleString2.size_;
    capacity_ = size_;
}

SimpleString SimpleString::substr(size_t pos, size_t count) const {
    /* SimpleString substr_data;
     delete[] substr_data.data_;
     size_t data_len = std::strlen(data_);
     size_t substr_len = std::min(count, data_len - pos);
     substr_data.data_ = new char[substr_len + 1];
     std::memcpy(substr_data.data_, data_+pos, substr_len);
     substr_data.size_=substr_data.capacity_ = ::strlen(substr_data.data_);

     return substr_data;
   }
 */
    char *substr_data;

    size_t data_len = std::strlen(data_);
    size_t substr_len = std::min(count, data_len - pos);
    substr_data = new char[substr_len + 1];
    std::memcpy(substr_data, data_ + pos, substr_len);
    substr_data[substr_len] = '\0';
    SimpleString new_substr(substr_data);
    delete[]substr_data;
    return new_substr;


}
int SimpleString::compare(const SimpleString &SimpleString2, bool case_sensitive) const {

    if (this == &SimpleString2) {
        return 0;
    }

    int cmp;
    if (case_sensitive) {
        cmp = strncmp(data_, SimpleString2.data_, size_);
    } else {
        cmp = strncasecmp(data_, SimpleString2.data_, size_);
    }

    if (cmp < 0) {
        return -1;
    } else if (cmp > 0) {
        return 1;
    } else {
        if (size_ < SimpleString2.size_) {
            return -1;
        } else if (size_ > SimpleString2.size_) {
            return 1;
        } else {
            return 0;
        }
    }
}

SimpleString::SimpleString(SimpleString&& SimpleString2)
        :// data_(nullptr)
         size_(0)
        , capacity_(0)
{
    delete[] data_;
    data_ = SimpleString2.data_;
    size_ = SimpleString2.size_;
    capacity_ = SimpleString2.capacity_;
    //delete[] data_;
    SimpleString2.data_ = new char [size_];
    SimpleString2.size_ = 0;
    SimpleString2.capacity_ = 0;
    data_[size_] = '\0';
    ++instances_;
}