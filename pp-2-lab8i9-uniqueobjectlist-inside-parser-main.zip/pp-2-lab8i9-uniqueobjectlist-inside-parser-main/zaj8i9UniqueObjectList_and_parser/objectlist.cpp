#include <memory>
#include <stdexcept>
#include <utility>  // std::exchange()
#include "objectlist.h"
#include "object.h"

/*
struct ObjectList::Node
{
    value_type* object = nullptr;
    std::unique_ptr<Node> next = nullptr;

    Node(value_type* objct)
            : object(objct)
    {}

    Node(value_type* objct, std::unique_ptr<Node> next)
            : object(objct), next(std::move(next))
    {}

};


*/
ObjectList::~ObjectList()
{
    clear();
}


void ObjectList::push_front(value_type *newObject) {
    if (newObject == nullptr) {
        return;
    }

    Node* current = head;
    while (current != nullptr) {
        if (*(current->value) == *newObject) {
            return;
        }
        current = current->next;
    }

    Node* new_node = new Node(newObject);
    new_node->next = head;
    head = new_node;

    if (tail == nullptr) {
        tail = head;
    }

    ++count;
}


void ObjectList::pop_front() {

    Node* temp = head;
    head = head->next;
    delete temp;
    if (head == nullptr) {
        tail = nullptr;
    }
    --count;
}

//void ObjectList::erase_after(iterator position){
//    Node* first = head;
//    while(first!= nullptr){

//    }
//}

/// tego std::forward_list nie ma
//void ObjectList::erase(iterator position) ;



//}
//ObjectList::ObjectList() = default;
//ObjectList::~ObjectList() = default;

