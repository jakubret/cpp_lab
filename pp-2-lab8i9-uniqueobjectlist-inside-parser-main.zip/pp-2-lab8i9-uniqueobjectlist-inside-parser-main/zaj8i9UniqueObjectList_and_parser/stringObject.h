#pragma once

#include <iosfwd>
#include <string>
#include <utility>
#include "object.h"


class StringObject : public Object
{
    std::string text;

public:
//     TODO:
    explicit StringObject(std::string  str) : text(std::move(str)) {}
    bool operator==(const Object& obj) const override;
    StringObject():text(){}
    ~StringObject() override = default;
     Object* clone() const override
    {
       return new StringObject(*this);
    }
};
