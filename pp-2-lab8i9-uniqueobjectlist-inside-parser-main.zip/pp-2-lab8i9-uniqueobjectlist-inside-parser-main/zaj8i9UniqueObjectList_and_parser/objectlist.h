#pragma once

#include <cinttypes>  // std::size_t
#include <memory>  // std::unique_ptr (dla chętnych)
#include <set>


//#define UNIMPLEMENTED_OBJECT_LIST_CONSTRUCTOR_SIZE_EMPTY_METHODS
//#define UNIMPLEMENTED_PUSH_FRONT
//#define UNIMPLEMENTED_POP_FRONT
//#define UNIMPLEMENTED_FRONT
//#define UNIMPLEMENTED_CLEAR
//#define UNIMPLEMENTED_REVERSE // rozmowa kwalifikacyjna
//#define UNIMPLEMENTED_ITERATOR_METHODS_AT_LEAST_EMPTY
//#define UNIMPLEMENTED_ITERATORS
//#define UNIMPLEMENTED_ERASE_AFTER
//#define UNIMPLEMENTED_ERASE


class Object;



using value_type = Object;
class ObjectList
{

        struct Node{
        Node* next;
        Node * prev;
        value_type* value;
        explicit Node(value_type* v) : value(v), next(nullptr), prev(nullptr) {}
    };

    Node* head{};
    Node* tail{};
    size_t count{};

public:

    ObjectList() : head(nullptr), tail(nullptr), count(0){}

    ObjectList(const ObjectList& list2) : head(nullptr), tail(nullptr), count(0) {
        Node* temp = list2.head;
        while (temp != nullptr) {
            Node* new_node = new Node(temp->value);
            if (head == nullptr) {
                head = new_node;
                tail = new_node;
            } else {
                tail->next = new_node;
                new_node->prev = tail;
                tail = new_node;
            }
            ++count;
            temp = temp->next;
        }
    }

    ObjectList(ObjectList&& move) noexcept : head(move.head), tail(move.tail), count(move.count) {
        move.head = nullptr;
        move.tail = nullptr;
        move.count = 0;
    }


    ObjectList& operator=(const ObjectList& other) {
        if (this == &other) {
            return *this;
        }

        clear();

        Node* temp = other.head;
        while (temp != nullptr) {
            Node* new_node = new Node(temp->value);
            if (head == nullptr) {
                head = new_node;
                tail = new_node;
            } else {
                tail->next = new_node;
                new_node->prev = tail;
                tail = new_node;
            }
            ++count;
            temp = temp->next;
        }

        return *this;
    }

    ObjectList& operator=(ObjectList&& other) noexcept {
        if (this == &other) {
            return *this;
        }

        clear();

        head = other.head;
        tail = other.tail;
        count = other.count;

        other.head = nullptr;
        other.tail = nullptr;
        other.count = 0;

        return *this;
    }

    size_t size() const
    {
        size_t count = 0;
        Node* current = head;
        while (current != nullptr) {
            ++count;
            current = current->next;
        }
        return count;
    }
    bool empty() const{
        return count == 0;

    }
    ~ObjectList();

    void clear() {
        while (head != nullptr) {
            Node* next = head->next;
            delete head;
            head = next;
        }
        tail = nullptr;
        count = 0;
    }

    void reverse() noexcept {
        Node* temp = nullptr;
        Node* current = head;

        while (current != nullptr) {
            Node* next = current->next;
            current->next = temp;
            temp = current;
            current = next;
        }

        tail = head;
        head = temp;
    }

    value_type& front(){
        return *(head->value);
    }


    class iterator {

    public:
        iterator& operator++() {
            if (temp)
                temp = temp->next;
            return *this;
        }
        bool operator!=(const iterator& other) const {
            return temp != other.temp;
        }

        value_type& operator*() const {
            return *(temp->value);
        }

        explicit iterator(Node* n) : temp(n) {}

        Node* temp;
    };

    iterator begin() {

        return iterator{head};
    }

    iterator end() {

            return iterator{nullptr};

    }

    /**
     * @brief push_front
     * @param newObject
     * Wpierw sprawdzamy czy obiekt już jest w liście
     */
    void push_front( value_type* newObject);


    void pop_front( );

    void erase_after(iterator position) {
        Node *temp = head;
        while (temp != nullptr) {
            if (temp == position.temp) {
                Node *to_delete = temp->next;
                temp->next = temp->next->next;
                delete to_delete;
                return;
            }
            temp = temp->next;
        }
    }
    /// tego std::forward_list nie ma
    void erase(iterator position){
        Node* temp = head;
        while(temp != nullptr){
            if(temp->next == position.temp){
                Node* to_delete = temp->next;
                temp->next = temp->next->next;
                delete to_delete;
                return;
            }
            temp = temp->next;
        }
    }

    /// dla chętnych, tego testy nie sprawdzają:
    ObjectList reverse_copy() const;

    /// dla chętnych, tego testy nie sprawdzają:
    void sort() noexcept;

protected:
    // TODO:
};
