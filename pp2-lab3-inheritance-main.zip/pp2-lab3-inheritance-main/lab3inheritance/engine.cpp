#include <algorithm>
#include "engine.h"
#include "player.h"
#include "stage.h"
#include "shoot.h"
#include "enemy.h"


namespace {
inline auto signum(int x)
{
    return (x > 0) - (x < 0);
}

Direction randDirection()
{
    auto randEdge = rand() % static_cast<uint8_t>(Direction::UPPER_LEFT);
    return static_cast<Direction>(randEdge);
}
} // namespace


Position generateNewEnemyPosition(int width, int height)
{
    Position position2Generate = Position(rand() % width, rand() % height);

    switch (randDirection()) {
        case Direction::UP:
            position2Generate.y_ = height-1;
            break;
        case Direction::DOWN:
            position2Generate.y_ = 0;
            break;
        case Direction::LEFT:
            position2Generate.x_ = 0;
            break;
        case Direction::RIGHT:
            position2Generate.x_ = width-1;
            break;
        default:
            break;
    }
    return position2Generate;
}


Engine::~Engine() = default;



Engine::Engine(std::size_t stageWidth, std::size_t stageHeight):
    player_(new Player), stage_(new Stage(stageWidth, stageHeight))
{

    player_->setPosition(Position(stageWidth / 2, stageHeight / 2));
}

void Engine::update()
{
    updateBullets();
    updateEnemies();
    randEnemies();
}

void Engine::updateBullets()
{
    // TODO...
}

void Engine::updateEnemies()
{
    // TODO...
    std::vector<std::shared_ptr<Enemy>> newEnemies;
    for (const auto& enemy : enemies_) {
        if (enemy->isAlieve()) {
            newEnemies.push_back(enemy);
            enemy->moveRight();
        }
    }
    enemies_ = newEnemies;

}

void Engine::movePlayerUp()
{

    player_->moveUp();
}

void Engine::movePlayerDown()
{

    player_->moveDown();
}

void Engine::movePlayerLeft()
{

    player_->moveLeft();
}
void Engine::movePlayerRight()
{

    player_->moveRight();
}

void Engine::playerShoots()
{

    Shoot newShoot(player_->direction(), player_->position());
    shoots_.push_back(newShoot);
}

Position Engine::playerPosition() const
{
    return player_->position();
}

Direction Engine::playerDirection() const
{

    return player_->direction();
}

bool Engine::isPlayerAlieve() const
{

    return player_->isAlieve();
}

std::size_t Engine::stageWidthCells() const
{
    return stage_->width();
}
std::size_t Engine::stageHeightCells() const
{
    return stage_->height();
}

void Engine::randEnemies(Position (*positionGenerator)(int,int))
{
    if (enemies_.size() < maxEnemies_)
    {

    }
        // TODO...
    }

/// metody zwracające informacje na temat obiektów w grze
const std::vector<Shoot>& Engine::shoots()
{
    const Position& playerPos = player_->position();
    const Direction& playerDir = player_->direction();
    Position shootPos;

    switch (playerDir) {
        case Direction::UP:
            shootPos = Position(playerPos.x(), playerPos.y()-1);
            break;
        case Direction::DOWN:
            shootPos = Position(playerPos.x(), playerPos.y()+1);
            break;
        case Direction::LEFT:
            shootPos = Position(playerPos.x()-1, playerPos.y());
            break;
        case Direction::RIGHT:
            shootPos = Position(playerPos.x()+1, playerPos.y());
            break;
    }

    shoots_.emplace_back(playerDir, shootPos);
}
