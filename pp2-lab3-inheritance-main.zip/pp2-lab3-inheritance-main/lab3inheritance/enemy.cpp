#include "enemy.h"

    Enemy::Enemy(Position position, int maxLife)
            : Object(ObjectType::OBJECT_ENEMY, position) ,maxLife(maxLife), life(maxLife){}
    double Enemy::lifePercent(){
        return static_cast<float>(life/maxLife *100);
    }
    bool Enemy::isAlieve() const {
        return life > 0;

    }
    void Enemy::decreaseLife(int damage){
        life= life - damage;
        if (life < 0) {
            life = 0;
        }
    }
