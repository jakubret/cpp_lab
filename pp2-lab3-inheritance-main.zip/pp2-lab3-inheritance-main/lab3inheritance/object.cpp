#include "object.h"

Object::Object( ObjectType objectType, Position position)
    : objectType1(objectType) , position1(position) {}


Position Object::position() const {
    return position1;
}
ObjectType Object::type() const {
    return objectType1;
}
void Object::setPosition(Position p) {
    position1 = p;
}
void Object::moveUp(){
    position1.moveUp();
}
void Object::moveDown(){
    position1.moveDown();
}
void Object::moveLeft() {
    position1.moveLeft();
}
void Object::moveRight(){
    position1.moveRight();
}
