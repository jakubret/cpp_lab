#include <iostream>
#include <string>
#include <stdexcept> // std::out_of_range()
#include <iomanip>   // std::setw()

using namespace std;

#include "matrix.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym"
#else
    #pragma message ("Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym")
#endif





TwoDimensionMatrix::TwoDimensionMatrix() {
    for (size_t i = 0; i < size_; i++) {
        for (size_t j = 0; j < size_; j++) {
            matrix_[i][j] = 0;
        }
    }
}

TwoDimensionMatrix::TwoDimensionMatrix(const TwoDimensionMatrix &CopyConstr)
{
    for (size_t i = 0; i < size_; i++) {
        for (size_t j = 0; j < size_; j++) {
            matrix_[i][j] = CopyConstr.matrix_[i][j];
        }

    }
   // operator=(CopyConstr.matrix_);
}

TwoDimensionMatrix::TwoDimensionMatrix(const MatrixElement matrix[size_][size_]){
    for (size_t i = 0; i < size_; i++) {
        for (size_t j = 0; j < size_; j++) {
            matrix_[i][j] = matrix[i][j];
        }

    }
}


//constexpr size_t TwoDimensionMatrix::size()