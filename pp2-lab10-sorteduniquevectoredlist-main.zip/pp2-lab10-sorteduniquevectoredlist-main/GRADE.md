Dear Student,

I'm happy to announce that you've managed to get **2.8** out of 3 points for this assignment.

There still exist some issues that should be addressed before the deadline: **2023-05-30 23:50:00 CEST (+0200)**. For further details, please refer to the following list:

<details><summary>Nie wszystkie testy przeszły! Oto lista tych co nie przeszły:</summary>1. SortedUniqueVectoredListTests.pushBack_pushingNotSortedElements_expectedElementsInContainerSorted</details>
<details><summary>Cppcheck znalazł potencjalne błędy (to narzędzie może się pomylić)</summary>/tmp/tmprlxleawm/student/zaj10SortedUniqueVectoredList/SortedUniqueVectoredList.cpp:157:0: warning: The function 'erase' is never used. [unusedFunction]<br>void SortedUniqueVectoredList::erase(const string &value)<br>^<br></details>

-----------
I remain your faithful servant\
_Bobot_