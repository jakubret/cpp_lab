#include <stdexcept> // std::out_of_range
#include <utility>   // std::exchange
#include <array>
#include <limits>
#include <algorithm>
#include <string>
#include "SortedUniqueVectoredList.h"
using namespace std;


/** class SortedUniqueVectoredList::Bucket
 * @param size ilosc elementow w kubelku, tworzac pusty ma byc 0
 * @param values elementy kubelka, jako tablica statyczna
 * @param BUCKET_SIZE ilosc elementow w statycznej tablicy
 * @param bucketCount_ ilosc kubelkow
 * @param next wskaznik na nastepny @ref Bucket, a jesli takiego nie ma na nullptr
 * @param previous wskaznik na poprzedni @ref Bucket, a jesli takiego nie ma na nullptr
 * @note jest to klasa zrobiona przy pomocy [idiomu PIMPL](https://en.cppreference.com/w/cpp/language/pimpl),
 *       ktory polega na tym, ze w klasie zewnetrznej jest jedynie deklaracja klasy wewnetrznej, ktora jest zaimplementowana w pliku zrodlowym **/
struct SortedUniqueVectoredList::Bucket
{
    constexpr static size_t BUCKET_SIZE = 10;

    std::array<std::string, BUCKET_SIZE> values;
    size_t size{};

    Bucket* next = nullptr;
    Bucket* previous = nullptr;
};


SortedUniqueVectoredList::SortedUniqueVectoredList(const SortedUniqueVectoredList &source):
        head(nullptr), tail(nullptr), size_(0), capacity_(0), bucketCount_(0)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    copy(source);
}

SortedUniqueVectoredList::SortedUniqueVectoredList(SortedUniqueVectoredList &&another) noexcept
        : head(nullptr), tail(nullptr), size_(0), capacity_(0), bucketCount_(0)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    move(std::move(another));
}

SortedUniqueVectoredList::~SortedUniqueVectoredList()
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    //free();
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        Bucket* tmp2 = tmp->next;
        delete tmp;
        tmp = tmp2;
    }
    head = nullptr;
    tail = nullptr;
    size_ = 0;
    capacity_ = 0;
    bucketCount_ = 0;


}

SortedUniqueVectoredList &SortedUniqueVectoredList::operator=(SortedUniqueVectoredList &&another)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    if (this != &another)
    {
        this->move(std::move(another));
    }
    return *this;
}



void SortedUniqueVectoredList::insert(const string& value)
{
    if (contains(value))
        return;

    if (head == nullptr)
    {
        head = new Bucket;
        head->values[0] = value;
        head->size++;
        tail = head;
        size_++;
        capacity_++;
        bucketCount_++;
    }
    else
    {
        Bucket* tmp = head;
        while (tmp != nullptr)
        {
            auto pos = std::lower_bound(tmp->values.begin(), tmp->values.begin() + tmp->size, value);
            if (pos != tmp->values.begin() + tmp->size && *pos == value)
                return;
            if (tmp->size < Bucket::BUCKET_SIZE)
            {
                std::copy_backward(pos, tmp->values.begin() + tmp->size, tmp->values.begin() + tmp->size + 1);
                *pos = value;
                tmp->size++;
                size_++;
                return;
            }

            tmp = tmp->next;
        }

        allocate_new_bucket();
        tail->next = new Bucket;
        tail->next->previous = tail;
        tail = tail->next;

        tail->values[tail->size] = value;
        tail->size++;
        size_++;
        bucketCount_++;

        sort_container();
    }
}

void SortedUniqueVectoredList::sort_container()
{
    std::vector<string> all_values;

    Bucket* tmp = head;
    while (tmp != nullptr)
    {
        for (int i = 0; i < tmp->size; i++)
        {
            all_values.push_back(tmp->values[i]);
        }
        tmp = tmp->next;
    }

    std::sort(all_values.begin(), all_values.end());

    tmp = head;
    int index = 0;
    while (tmp != nullptr)
    {
        for (int i = 0; i < tmp->size; i++)
        {
            tmp->values[i] = all_values[index];
            index++;
        }
        tmp = tmp->next;
    }
}


void SortedUniqueVectoredList::erase(const string &value)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym (opcjonalne zadanie)

}

SortedUniqueVectoredList::operator std::string() const
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    string result;
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        for(int i = 0; i < tmp->size; i++)
        {
            result += tmp->values[i];

        }
        tmp = tmp->next;
    }
    return result;


    //return {};
}

void SortedUniqueVectoredList::allocate_new_bucket()
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym

    capacity_ += Bucket::BUCKET_SIZE;
    bucketCount_++;
}

void SortedUniqueVectoredList::free()
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        Bucket* tmp2 = tmp->next;
        delete tmp;
        tmp = tmp2;
    }
    head = nullptr;
    tail = nullptr;
    size_ = 0;
    capacity_ = 0;
    bucketCount_ = 0;

}

void SortedUniqueVectoredList::move(SortedUniqueVectoredList &&another)
{

    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    head = another.head;
    tail = another.tail;
    size_ = another.size_;
    capacity_ = another.capacity_;
    bucketCount_ = another.bucketCount_;
    another.head = nullptr;
    another.tail = nullptr;
    another.size_ = 0;
    another.capacity_ = 0;
    another.bucketCount_ = 0;



}

void SortedUniqueVectoredList::copy(const SortedUniqueVectoredList &other)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = other.head;
    while(tmp != nullptr)
    {
        for(int i = 0; i < tmp->size; i++)
        {
            insert(tmp->values[i]);
        }
        tmp = tmp->next;
    }

}

bool SortedUniqueVectoredList::contains(const string &value) const
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        for(int i = 0; i < tmp->size; i++)
        {
            if(tmp->values[i] == value)
            {
                return true;
            }
        }
        tmp = tmp->next;
    }


    return false;
}

SortedUniqueVectoredList SortedUniqueVectoredList::operator-(const SortedUniqueVectoredList &another) const
{
    SortedUniqueVectoredList ret;
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        for(int i = 0; i < tmp->size; i++)
        {
            if(!another.contains(tmp->values[i]))
            {
                ret.insert(tmp->values[i]);
            }
        }
        tmp = tmp->next;
    }


    return ret;
}

SortedUniqueVectoredList& SortedUniqueVectoredList::operator*=(const size_t howManyTimesMultiply)
{
    Bucket* tmp = head;
    while (tmp != nullptr)
    {
        for (int i = 0; i < tmp->size; i++)
        {
            string concatenatedTexts = tmp->values[i];
            for (int j = 0; j < (howManyTimesMultiply - 1); j++)
            {
                concatenatedTexts += tmp->values[i];
            }
            tmp->values[i] = concatenatedTexts;
        }
        tmp = tmp->next;
    }

    return *this;
}

string &SortedUniqueVectoredList::operator[](size_t index)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        if(index < tmp->size)
        {
            return tmp->values[index];
        }
        index -= tmp->size;
        tmp = tmp->next;
    }

    throw std::out_of_range("");

}

const string& SortedUniqueVectoredList::operator[](size_t index) const
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    Bucket* tmp = head;
    while(tmp != nullptr)
    {
        if(index < tmp->size)
        {
            return tmp->values[index];
        }
        index -= tmp->size;
        tmp = tmp->next;
    }


    throw std::out_of_range("");
}

SortedUniqueVectoredList &SortedUniqueVectoredList::operator=(const SortedUniqueVectoredList &another)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    if(this == &another)
    {
        return *this;
    }
    free();
    copy(another);


    return *this;
}
