#include <functional>
#include <algorithm>
#include <string>
#include <cstring>
#include <stdexcept>
#include <utility> // std::exchange
#include "PtrCStringVector.h"
using namespace std;


PtrCStringVector::PtrCStringVector()
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    data_ = nullptr;
    size_ = 0;
    capacity_ = 0;

}


PtrCStringVector::PtrCStringVector(const PtrCStringVector &source): PtrCStringVector()
{
    data_ = new char*[source.size_];
    size_ = source.size_;
    capacity_ = source.capacity_;

    for (size_t i = 0; i < size_; ++i)
    {
        size_t length = strlen(source.data_[i]) + 1;
        data_[i] = new char[length];
        memcpy(data_[i], source.data_[i], length);
    }
}


PtrCStringVector::~PtrCStringVector()
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym

    free();

}

PtrCStringVector &PtrCStringVector::operator=(const PtrCStringVector &source)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    if (this != &source)
    {
        free();
        PtrCStringVector temp(source);
        std::swap(data_, temp.data_);
        std::swap(size_, temp.size_);
        std::swap(capacity_, temp.capacity_);
    }
    return *this;
}

PtrCStringVector& PtrCStringVector::operator=(PtrCStringVector&& source)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    if (this != &source)
    {
        free();

        size_ = source.size_;
        capacity_ = source.capacity_;
        data_ = source.data_;

        source.size_ = 0;
        source.capacity_ = 0;
        source.data_ = nullptr;
    }
    return *this;
}

void PtrCStringVector::push_back(const char* text2Add)
{
    size_t textLength = strlen(text2Add);
    if (size_ == capacity_)
    {
        reserve(capacity_ + 20 );
    }
    data_[size_] = new char[textLength + 1];
    memcpy(data_[size_], text2Add, textLength + 1);
    size_++;
}




PtrCStringVector PtrCStringVector::operator+(const PtrCStringVector& anotherVector) const
{
    PtrCStringVector result;
    result.reserve(size_ + anotherVector.size_);

    if (size_ > 0) {
        const size_t dataSize = size_ * sizeof(char*);
        memcpy(result.data_, data_, dataSize);
        result.size_ = size_;
    }

    if (anotherVector.size_ > 0) {
        const size_t dataSize = anotherVector.size_ * sizeof(char*);
        memcpy(result.data_ + result.size_, anotherVector.data_, dataSize);
        result.size_ += anotherVector.size_;
    }

    return result;
}

char *PtrCStringVector::operator[](size_t index)
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym

    if(index >= size_){
        throw std::out_of_range("Index out of range");

    }
    return data_[index];

}
const char *PtrCStringVector::operator[](size_t index) const
{
    /// @todo zaimplementuj, szczegoly w pliku naglowkowym
    if(index >= size_){
        throw std::out_of_range("Index out of range");
    }
    else {
        return data_[index];
    }

}

PtrCStringVector PtrCStringVector::operator&(const PtrCStringVector& rhs) const
{
    PtrCStringVector temp;
    size_t minSize = std::min(size_, rhs.size_);
    size_t newSize = minSize + std::abs(static_cast<int>(size_) - static_cast<int>(rhs.size_));

    temp.reserve(newSize);

    for (size_t i = 0; i < minSize; ++i)
    {
        size_t combinedLength = strlen(data_[i]) + strlen(rhs.data_[i]);
        char* connected = new char[combinedLength + 1];
        strcpy(connected, data_[i]);
        strcat(connected, rhs.data_[i]);
        temp.data_[i] = connected;
    }

    if (size_ < rhs.size_)
    {
        for (size_t i = minSize; i < rhs.size_; ++i)
        {
            temp.data_[i] = rhs.data_[i];
        }
    }
    else if (size_ > rhs.size_)
    {
        for (size_t i = minSize; i < size_; ++i)
        {
            temp.data_[i] = data_[i];
        }
    }

    temp.size_ = newSize;
    return temp;
}


void PtrCStringVector::free()
{
    /// @todo sugeruje zaimplementowac, szczegoly w pliku naglowkowym


    delete[] data_;
    data_ = nullptr;
    size_ = 0;
    capacity_ = 0;

}

void PtrCStringVector::reserve(size_t new_capacity)
{
    if (new_capacity <= capacity_)
        return;

    char** new_data = new char*[new_capacity];
    std::memcpy(new_data, data_, size_ * sizeof(char*));

    delete[] data_;
    capacity_ = new_capacity;
    data_ = new_data;
}
