#ifndef MAC_OS_H
#define MAC_OS_H

/** Jako punkt z aktywnosci można zaimplementować klasę `MacOs` analogicznie jak dla pozostałych systemów
    Jako kolejny dodatkowy punkt z aktywności - jak się utworzy analogiczne testy
    Najlepiej jak wrzucisz implementacje do swojego repozytorium, ale proszę pokazać na zajęciach (nie zauważe jak mi ktoś nie pokaże, że zrobił)
**/

#endif // MAC_OS_H
