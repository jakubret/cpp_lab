#include <iostream>
using namespace std;
#include <optional>
#include "user.h"
#include "linux.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Funkcje sa do zaimplementowania. Instrukcja w pliku naglowkowym"
#else
    #pragma message ("Funkcje sa do zaimplementowania. Instrukcja w pliku naglowkowym")
#endif

std::size_t Linux::open_source_sympathizers_=0;
std::string Linux::distribution() const {
    return distribution_ ;
}
    std::size_t Linux::open_source_sympathizers()  {
    return open_source_sympathizers_;
}
Linux::Linux() {
    std::cout << "+" << distribution_ << '\n';
    ++open_source_sympathizers_;
}
Linux::Linux(const std::string& distribution) : distribution_(distribution) {
    std::cout << "+" << distribution_ << '\n';
    ++open_source_sympathizers_;
}

Linux::~Linux() {
    std::cout << "~" << distribution_ << '\n';
    --open_source_sympathizers_;
}
std::size_t Linux::add_user(const std::string &user_name, const std::string &password  ){
    User user {user_name, password};
    users_.push_back(user);
    return users_.size() -1;


}
User Linux::user(std::size_t user_id) const {
    return  users_.at(user_id);

}
string Linux::user_home_directory(std::size_t user_id) const {
    return "/home/" + users_.at(user_id).user_name_ + "/";
}

std::optional<std::string> Linux::graphic_environment() const {
    return graphic_environment_;
}
void Linux::set_graphic_environment(const std::string& env) {
    graphic_environment_ = env;
}