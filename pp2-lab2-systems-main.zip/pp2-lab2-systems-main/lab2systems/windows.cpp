#include <iostream>
using namespace std;

#include "user.h"
#include "windows.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Funkcje sa do zaimplementowania. Instrukcja w pliku naglowkowym"
#else
    #pragma message ("Funkcje sa do zaimplementowania. Instrukcja w pliku naglowkowym")
#endif

std::size_t Windows::activated_systems_=0;
std::string Windows::version()const {
    return version_ ;
}

std::size_t Windows::activated_systems()   {
    return activated_systems_;
}
Windows::Windows() {
    std::cout << "Windows " << version_ << '\n';
    ++activated_systems_;
}
Windows::Windows(const std::string& version) : version_(version) {
    std::cout << "Windows " << version_ << '\n';
    ++activated_systems_;
}

std::size_t Windows::add_user(const std::string &user_name, const std::string &password  ){
    User user {user_name, password};
    users_.push_back(user);
    return users_.size() -1;


}
User Windows::user(std::size_t user_id) const {
    return  users_.at(user_id);

}
string Windows::user_home_directory(std::size_t user_id) const {
    return "C:\\Users\\" + users_.at(user_id).user_name_ ;
}
